<?php

?>
<html>
<head>
<title>Purple Hex</title>
<link rel="stylesheet" type="text/css" href="styles/pm_completed.css"/>
<meta name="viewport" content="width=device-width, initial-scale= 1.0, user-scalable=0" />
<script src="scripts/jquery-3.1.1.min.js"></script>
<script src="scripts/general.js"></script>
<link href="styles/font-awesome.min.css" rel="stylesheet">
</head>

<body>

	<div id="header">
		<div class="logo"> <a href="#">Purple<span>Hex</span></a></div>
		<li class="login_ico"><i class="fa fa-sign-in" aria-hidden="true"></i><a href="login.php">Login</a></li>
		<li class="login_ico"><i class="fa fa fa-truck" aria-hidden="true"></i><a href="shipment.php">Shipment</a></li>
		<li class="login_ico"><i class="fa fa fa-users" aria-hidden="true"></i><a href="customers.php">Customers</a></li>
	</div>

	<a class="mobile" href="#">MENU</a>

	<div id="container">
		 <div class="sidebar">
		 	<ul id="nav">
		 	<li><a href="index.html">Dashboard</a></li>
		 	<li><a href="web.html" target="_blank">Visit Website</a></li>
		 	<li><a href="#">General Settings</a>
		 		<div class="general">
		 			<ul id="gen">
        			<li><a href="gs_company_details.html">Company Details</a></li>
        			<li><a href="gs_social_details.html">Social Details</a></li>
        			<li><a href="gs_payment_settings.html">Payment Settings</a></li>
      				</ul>
      			</div>
		 	</li>
		 	<li><a href="#">Shipment Management</a>
		 		<div class="shipment">		
		 			<ul id="ship">
        				<li><a href="sm_add_new.html">Add New Shipment</a></li>
        				<li><a href="sm_undelivered_ship.php">Undelivered Shipment</a></li>
        				<li><a href="sm_delivered_ship.php">Delivered Shipment</a></li>
        				<li><a href="sm_returned_ship.php">Returned Shipment</a></li>
        				<li><a href="sm_import_ship.html">Import CSV Shipment</a></li>
      				</ul>
      		</li>

		 	<li><a href="#">Pickup Management</a>
		 		<div class="pickup">
		 			<ul>
		 				<li><a href="pm_generate.html">Generate Pickup</a></li>
		 				<li><a href="pm_running.php">Running Pickup List</a></li>
		 				<li><a class="selected" href="pm_completed.php">Completed Pickup List</a></li>
		 			</ul>
		 		</div>
		 	</li>
		 	<li><a href="#">COD</a>
		 		<div class="cod">
		 			<ul>
		 				<li><a href="cod_delivered.php">Delivered COD</a></li>
		 				<li><a href="cod_undelivered.php">Undelivered COD</a></li>
		 			</ul>
		 		</div>
		 	</li>
		 	<!--  <li><a href="#">Product Type</a>
		 		<div class="product">
		 			<ul>
		 				<li><a href="pt_add.html">Add Product Type</a></li>
		 				<li><a href="pt_show.html">Show Product Type</a></li>
		 			</ul>
		 		</div>
		 	</li>
		 	<li><a href="#">Zone Management</a>
		 		<div class="zone">
		 			<ul>
		 				<li><a href="zm_show.html">Show Zone List</a></li>
		 				<li><a href="zm_set.html">Set City Zone</a></li>
		 			</ul>
		 		</div>
		 	</li> -->
		 	<li><a href="login.php">Login</a></li>
		 	</ul>
		 </div>
		 <div class="content">
		 	
		 	<div id="box">
		 		<div class="box-top"><i class="fa fa-book" aria-hidden="true"></i> <h1>Completed Pickup List</h1> </div>
		 		<div class="box-panel">
		 			<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "purple_hex");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM pickup where status='completed'";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
                echo "<th>ID</th>";
                echo "<th>Date</th>";
                echo "<th>City</th>";
                echo "<th>Route Code</th>";
                echo "<th>Messenger</th>";
                echo "<th>Status</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['date'] . "</td>";
                echo "<td>" . $row['city'] . "</td>";
                echo "<td>" . $row['route_code'] . "</td>";
                echo "<td>" . $row['messenger'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>

		 		</div>
		 	</div>

		 	<div id="box">
		 		<div class="box-top"><i class="fa fa-building" aria-hidden="true"></i><h1> Delete Record </h1></div>
		 		<div class="box-panel">
		 	 <form action="pm_del.php" method="post">
		 	  Shipment ID:<br>
  							<input type="text" name="id"><br>
  							<input type="submit" value="Delete">
		 	</form>
		 	</div>
		 	</div>
		 	</div>
		 </div>
	</div>

</body>
</head>