	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>


<head>
	<title>Admin</title>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
         <link href="templates/admin/admin_assets/login/style.css" rel="stylesheet" />
    <script src="../cdn.jsdelivr.net/webshim/1.12.4/extras/modernizr-custom.js"></script>
<!-- polyfiller file to detect and load polyfills -->
<script src="../cdn.jsdelivr.net/webshim/1.12.4/polyfiller.js"></script>

<script>
  webshims.setOptions('waitReady', false);
  webshims.setOptions('forms-ext', {types: 'date'});
  webshims.polyfill('forms forms-ext');
</script>

<script type="text/javascript" src="templates/js/custom/elements.js"></script>
<script type="text/javascript" src="templates/js/validation.js"></script>
<script type="text/javascript" src="templates/js/ajax.js"></script>

<script type="text/javascript">var site_url="index.html";</script> 
<script type="text/javascript" src="languages_admin/lang_english/lang_main.js"></script> 


<script src="templates/js/jquery.min.js"></script>
    <script src="templates/js/typeahead.min.js"></script>
   
	<script type="text/javascript">
    $(document).ready(function(){
        $('input.typeahead').typeahead({
            name: 'contact',
            prefetch: 'customer_name.json',
            limit: 10
        });
    });  
    </script>
   
<div >

</div>

<!--================onclick edit data for set price====================-->
<!--===================================================================-->



</head>
<body id="body_id"  class="loginpage"  onLoad=" document.bar_code_Frm.barcode_id.focus();">

<div id="wrapper">
    
  <!--==============================leftpanel include condition===============================================-->
   
  	    
 <!--==================================================================================================-->    
     
	<section  >
	
		<!--<div>
			<div class="top-bar">

				<h1>Eagle Technosys</h1>
				
			</div><br />
		  <div class="select-bar-report" align="center">
		  <table border="0" cellpadding="0" cellspacing="0" width="25%">
		  	<form name="login_form" action="http://courierv6.couriersoftwares.com//admin.php?c=user&f=login" method="post">
		    <tr>
			  <td>Login Name</td>
			  <td align="center"><input type="text" name="loginname" value="" /></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
			  <td>Password</td>
			  <td align="center"><input type="password" name="password" value="" /></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
			  <td colspan="2" align="center"><input type="submit" name="submit" value="Login" /></td>
			</tr>
			</form>
		  </table>
		  </div>
			
		  
		</div>-->
     <!---------------   new---------------->
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset="UTF-8" /> 
    <title>
        HTML Document Structure
    </title>
</head>
<body onLoad="document.getElementById('username').focus();">      
<div id="wrapper">
  
<!--        
<div class="loginbox">
<div class="loginboxinner">
  <div class="logo">
    <h1>Eagle Technosys</h1>
    <p><span id="login_info"></span></p>
  </div>
  
  
  <br clear="all" />
  <br />
  <div class="nousername">
    <div class="loginmsg">The password you entered is incorrect.</div>
  </div>
  
  
  <div class="nopassword">
    <div class="loginmsg">The password you entered is incorrect.</div>
    <div class="loginf">
      <div class="thumb"><img alt="" src="images/thumbs/avatar1.png" /></div>
      <div class="userlogged">
        <h4></h4>
        <a href="index.html">Not <span></span>?</a> </div>
    </div>
   
  </div>
  nopassword--->
  
  <form id="login" name="login_form" action="index.html" method="post">
  <h1>Admin Log in</h1>
       <p style="padding-left:10%; padding-right:10%; padding-top:5%;">
    <label for="email">User Name</label><span id="username_info"></span>
        <input type="text" name="loginname" placeholder="User Name" id="username" value="admin" />
       
  </p>
  
  <p style="padding-left:10%; padding-right:10%;">
    <label for="password">Password</label> <span id="password_info"></span> 
        <input type="password" name="password" placeholder="Password" id="password" value="password" />
       
   </p>
     <p class="p-container" style="padding-left:10%; padding-right:10%;" >
    <button type="submit" class="btn btn-lg btn-block btn-info"  name="submit" onclick="return Valid_admin_login(document.login_form);">Sign In</button>
    </p>
    <div>&nbsp;</div>
     <div>&nbsp;</div>
  </form>
  
  </div>
</body>

<!-- Mirrored from courierv6.couriersoftwares.com/admin.php?c=user&f=login by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 13 Mar 2017 16:35:24 GMT -->
</html>

	
	</div>
</div>
	<div id="footer"></div>

    <script src="templates/admin/admin_assets/js/bootstrap.min.js"></script>
    <script src="templates/admin/admin_assets/js/jquery.metisMenu.js"></script>
    <script src="templates/admin/admin_assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="templates/admin/admin_assets/js/morris/morris.js"></script>
    <!-- Custom Js -->
    <script src="templates/admin/admin_assets/js/custom-scripts.js"></script>
    <script src="templates/admin/admin_assets/js/custom.js"></script>
	 <link rel="stylesheet" href="templates/css/bootstrap-select.css">
	<script src="templates/js/bootstrap-select.js"></script>

<!--=============chat options===========-->
 <div class="container" id="online_chat_window" style="display: none;"  >
  <div class="row col-md-12 pull-right">
    <div class="row chat-window-leftside col-xs-5 col-md-11 pull-right" id="chat_window_1">
      <div class="col-xs-12 col-md-12">
        <div class="chatpanel panel-default">
          <div class="panel-heading top-bar">
            <div class="col-md-8 col-xs-8">
              <h3 class="panel-title"><span class="glyphicon glyphicon-comment"></span> Chat Window</h3>
            </div>
            <div class="col-md-4 col-xs-4" style="text-align:right;">
            <div id="minmax_change" style="display:inline;"> <a onclick="reaison_min()" >
            <span id="minim_chat_window" class="glyphicon glyphicon-minus icon_minim"></span></a> </div>
            <a onclick="reaison_close()"><span  class="glyphicon glyphicon-remove icon_close" data-id="chat_window_1"></span></a> </div>
          </div>
    
    
     
    

          
          <input type="hidden" id="user_window_count" value="0"/>
                     <div class="panel-body msg_container_base" id="user_online" style="display:block;">
                                  <!--  
                    </form>
                    </div>-->
             
  		</div>
      </div>
    </div>
  </div>

 <div class="row col-md-12 pull-right" id="message_window" style="display: none;">
    <div class="row chat-window col-xs-5 col-md-8 pull-right" id="chat_window_1">
      <div class="col-xs-12 col-md-12">
        <div class="chatpanel panel-default">
          <div class="panel-heading top-bar">
            <div class="col-md-8 col-xs-8">
              <h3 class="panel-title"><span class="glyphicon glyphicon-comment"></span><span id="user_name"></span></h3>
            </div>
            <div class="col-md-4 col-xs-4" style="text-align: right;"> <a onclick="reaison_min_user()" ><span id=""class="glyphicon glyphicon-minus icon_minim"></span></a> <a onclick="reaison_close_user()"><span class="glyphicon glyphicon-remove icon_close" ></span></a> </div>
          </div>
            <div class="panel-body" id="user_min_max" style="display:block;background-color:#FFF;">
          <div class="msg_container_base" id="user_windows">

 </div>
  <div class="panel-footer">
            <div class="input-group">
              <input id="input_message" type="text" class="form-control input-sm chat_input" placeholder="Write your message here..." />
              <span class="input-group-btn">
              <button class="btn btn-primary btn-sm" id="btn-chat" onclick="send_message()"  >Send</button>
              </span> </div>
         </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<!--====================================-->

<!--==============================wating loader===========================-->
 
<!--======================================================================-->
<div id="shipment_wating_id" style="display:none; box-shadow: 0 0 15px #888888;  position:fixed; vertical-align:middle; top:50%; left:50%; margin-top:-125px; margin-left:-150px; z-index:99999">
  <div  style="width:400px; background-color: #fff;border:2px solid #FB9337;text-align:center;padding:0px;margin:0px">
  
    <div style="margin:0px; padding: 3px 0px 2px 0px;text-align:center;background-color:#FB9337;border:1px solid #FB9337 ;width:100%;"> <a title="Upgrade Package" class="VSlabel" style="text-weight:bold;text-decoration:none;color:#fff;"><b>Please Wait...</b></a> </div>
  </div>
  <div style=" height:auto; background-color:#FCFCFC; padding:8px; padding-left:50px;">
 					
                   <img src="images/please_wait.gif" />
                    
  </div>
</div>
</body>

</html>
