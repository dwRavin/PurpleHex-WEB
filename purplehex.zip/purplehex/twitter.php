<?php
 
require 'connection.php';
$conn    = Connect();


$twitter    = $conn->real_escape_string($_POST['twitter']);


$query   = "INSERT into social_details (twitter) VALUES('" .$twitter. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=gs_social_details.html');

?>