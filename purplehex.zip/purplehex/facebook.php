<?php
 
require 'connection.php';
$conn    = Connect();


$facebook    = $conn->real_escape_string($_POST['facebook']);


$query   = "INSERT into social_details (facebook) VALUES('" .$facebook. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=gs_social_details.html');

?>