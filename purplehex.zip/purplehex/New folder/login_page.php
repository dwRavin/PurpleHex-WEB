<html>
	<form action="login.php" method="post">
		
		Username: <input type="text" name="username" placeholder="username"><p>
		Password: <input type="password" name="password"><p>
					<input type="Submit" value="Login">
	</form>

</html>