<?php
 
require 'connection.php';
$conn    = Connect();


$id    = $conn->real_escape_string($_POST['id']);


$query   =  "DELETE FROM shipment WHERE id='".$id."'";  

$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('Deleted Successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=sm_undelivered_ship.php');

?>