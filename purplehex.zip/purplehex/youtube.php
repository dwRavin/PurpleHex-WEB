<?php
 
require 'connection.php';
$conn    = Connect();


$youtube    = $conn->real_escape_string($_POST['youtube']);


$query   = "INSERT into social_details (youtube) VALUES('" .$youtube. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=gs_social_details.html');

?>