<?php
 
require 'connection.php';
$conn    = Connect();


$paypal    = $conn->real_escape_string($_POST['paypal']);


$query   = "INSERT into payment_settings (paypal) VALUES('" .$paypal. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=gs_payment_settings.html');

?>