<?php
 
require 'connection.php';
$conn    = Connect();


$country    = $conn->real_escape_string($_POST['country']);
$city    = $conn->real_escape_string($_POST['city']);
$route    = $conn->real_escape_string($_POST['route']);
$messenger   = $conn->real_escape_string($_POST['messenger']);
$status   = $conn->real_escape_string($_POST['status']);


$query   = "INSERT into pickup (country,city,route_code,messenger,status) VALUES('" .$country. "','" .$city. "' , '" .$route. "','" .$messenger. "','" .$status. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=pm_generate.html');

?>