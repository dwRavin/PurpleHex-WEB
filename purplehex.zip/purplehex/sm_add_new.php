<?php
 
require 'connection.php';
$conn    = Connect();


$date    = $conn->real_escape_string($_POST['date']);
$product_type    = $conn->real_escape_string($_POST['product_type']);
$payment_type    = $conn->real_escape_string($_POST['payment_type']);
$sender_fname    = $conn->real_escape_string($_POST['sender_fname']);
$sender_lname    = $conn->real_escape_string($_POST['sender_lname']);
$sender_country    = $conn->real_escape_string($_POST['sender_country']);
$sender_city    = $conn->real_escape_string($_POST['sender_city']);
$sender_zip    = $conn->real_escape_string($_POST['sender_zip']);
$sender_address    = $conn->real_escape_string($_POST['sender_address']);
$sender_phno    = $conn->real_escape_string($_POST['sender_phno']);
$sender_email    = $conn->real_escape_string($_POST['sender_email']);
$reciever_fname    = $conn->real_escape_string($_POST['reciever_fname']);
$reciever_lname    = $conn->real_escape_string($_POST['reciever_lname']);
$reciever_country    = $conn->real_escape_string($_POST['reciever_country']);
$reciever_city    = $conn->real_escape_string($_POST['reciever_city']);
$reciever_zip    = $conn->real_escape_string($_POST['reciever_zip']);
$reciever_address    = $conn->real_escape_string($_POST['reciever_address']);
$reciever_phno    = $conn->real_escape_string($_POST['reciever_phno']);
$reciever_email    = $conn->real_escape_string($_POST['reciever_email']);
$status = $conn->real_escape_string($_POST['status']);

$query   = "INSERT into shipment (date,product_type,payment_type,sender_fname,sender_lname,sender_country,sender_city,sender_zip,sender_address,sender_phno,sender_email,reciever_fname,reciever_lname,reciever_country,reciever_city,reciever_zip,reciever_address,reciever_phno,reciever_email,status) VALUES('" .$date. "','" .$product_type. "' , '" .$payment_type. "','" .$sender_fname. "','" .$sender_lname. "','" .$sender_country. "','" .$sender_city. "','" .$sender_zip. "','" .$sender_address. "','" .$sender_phno. "','" .$sender_email. "','" .$reciever_fname. "','" .$reciever_lname. "','" .$reciever_country. "','" .$reciever_city. "', '" .$reciever_zip. "', '" .$reciever_address. "', '" .$reciever_phno. "','" .$reciever_email. "', '" .$status. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=sm_add_new.html');

?>