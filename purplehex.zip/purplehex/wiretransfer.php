<?php
 
require 'connection.php';
$conn    = Connect();


$wiretransfer    = $conn->real_escape_string($_POST['wiretransfer']);


$query   = "INSERT into payment_settings (wiretransfer) VALUES('" .$wiretransfer. "')";
$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=gs_payment_settings.html');

?>