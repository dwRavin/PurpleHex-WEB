<?php
 
require 'connection.php';
$conn    = Connect();


$company_name    = $conn->real_escape_string($_POST['company_name']);
$company_address    = $conn->real_escape_string($_POST['company_address']);
$phone    = $conn->real_escape_string($_POST['phone']);
$fax    = $conn->real_escape_string($_POST['fax']);
$email    = $conn->real_escape_string($_POST['email']);


$query   =  "INSERT into company_details (company_name,company_address,phone,fax,email) VALUES('" .$company_name. "','" .$company_address. "' , '" .$phone. "','" .$fax. "','" .$email. "')";  

$success = $conn->query($query);
 
if (!$success) {
    die("Couldn't enter data: ".$conn->error);
 
}
 
 echo "<script type='text/javascript'>alert('Updated Successfully!')</script>";
 
$conn->close();
 
header('Refresh: 1;url=gs_company_details.html');

?>