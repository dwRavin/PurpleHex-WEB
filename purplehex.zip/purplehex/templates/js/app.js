var app = angular.module('courier', []);

app.controller('Notification', function($scope, $http) {
    
    
    $scope.sendNotification = function(tokan_data) {
		console.log('funtion running now')
       // Define relevant info
var jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJmNjA2OGYxZi0xYTk4LTRlMDItYWZlNS1jNDNjM2Y2MmY5ZjUifQ.2d98RLDJKz3oIp5H00GsQzqhgXkZVSUgA-YjIg4od1c';
var tokens = tokan_data;
var profile = 'sec';

// Build the request object
var req = {
  method: 'POST',
  url: 'https://api.ionic.io/push/notifications',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + jwt
  },
  data: {
    "tokens": tokens,
    "profile": profile,
    "notification": {
      "title": "You got a new pickup list",
      "message": "Hello world!",
      "android": {
        "title": "Hey",
        "message": "this is bimal!",
		"payload": {
        "foo": "bar"
      }
      }
    }
  }
};

// Make the API call
$http(req).success(function(resp){
  // Handle success
  console.log("Ionic Push: Push success", resp);
}).error(function(error){
  // Handle error 
  console.log("Ionic Push: Push error", error);
});
    }

});




//
//app.config(function($interpolateProvider) {
//    $interpolateProvider.startSymbol('[|').endSymbol('|]');
//});
